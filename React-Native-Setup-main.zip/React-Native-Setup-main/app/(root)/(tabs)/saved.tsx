import {View, Text} from 'react-native';
import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
export default function Saved()
{
    return(
        <SafeAreaView>
            <View>
                <Text>Saved</Text>
            </View>
        </SafeAreaView>
    );
}